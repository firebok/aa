//
//  File.swift
//  cl
//
//  Created by DamII on 10/29/22.
//  Copyright © 2022 DamII. All rights reserved.
//

import UIKit
struct mensaje {
    let nombre: String?
    let mensaje: String?
    let estado: String?
}
