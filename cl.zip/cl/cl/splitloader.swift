//
//  splitloader.swift
//  cl
//
//  Created by DamII on 10/29/22.
//  Copyright © 2022 DamII. All rights reserved.
//

import UIKit

enum PlistError: Error {
    case invalidResource
    case parsingFailure
}

class PlistLoader {
    static func array(fromFile name: String, ofType type: String) throws -> [[String: String]] {
        guard let path = Bundle.main.path(forResource: name, ofType: type) else {
            throw PlistError.invalidResource
        }
        
        guard let array = NSArray(contentsOfFile: path) as? [[String: String]] else {
            throw PlistError.parsingFailure
        }
        
        return array
    }
}


class ContactsSource {
    static var mensajes: [Mensaje] {
        let data = try! PlistLoader.array(fromFile: "Mensaje", ofType: "plist")
        return data.flatMap { Mensaje(dictionary: $0) }
    }
    
}
