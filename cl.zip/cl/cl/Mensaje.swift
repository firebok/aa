//
//  Mensaje.swift
//  cl
//
//  Created by DamII on 10/29/22.
//  Copyright © 2022 DamII. All rights reserved.
//

struct Mensaje {
    let nombre: String
    let mensaje: String
    let estado: String
   
}

extension Mensaje {
    
    struct Key {
        static let nombre = "nombre"
        static let mensaje = "mensaje"
        static let estado = "estado"
        
    }
    
    init?(dictionary: [String: String]) {
        guard let nombreString = dictionary[Key.nombre],
            let mensajeString = dictionary[Key.mensaje],
        let estadoString = dictionary[Key.estado] else { return nil }
        
        self.nombre = nombreString
        self.mensaje = mensajeString
        self.estado = estadoString
        
        
        favorite = false
    }
}
