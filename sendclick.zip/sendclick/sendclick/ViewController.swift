//
//  ViewController.swift
//  sendclick
//
//  Created by yyyy on 20/11/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

