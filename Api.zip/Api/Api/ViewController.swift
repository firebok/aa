//
//  ViewController.swift
//  Api
//
//  Created by DamII on 11/12/22.
//  Copyright © 2022 DamII. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var idtxt: UITextField!
    
    
    @IBOutlet weak var useridlab: UILabel!
    
    
    @IBOutlet weak var titlelabe: UILabel!
    
    
    
    @IBOutlet weak var bodylabe: UILabel!
    
    @IBOutlet weak var buscar: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    let baseurl = URL(string: "https://jsonplaceholder.typicode.com/")
    @IBAction func userid(_ sender: Any) {
    }
    @IBAction func buscar(_ sender: Any) {
        
        guard let postURL = URL(string: "posts/\(idtxt.text!)",relativeTo: baseurl) else {
            return
        }
        
        guard let postURL2 = URL(string: "posts",relativeTo: baseurl) else {
            return
        }
        
        
        let session = URLSession(configuration: .default)
        let request = URLRequest(url: postURL)
        let request2 = URLRequest(url: postURL2)
        
        let tarea = session.dataTask(with: request) { (data,response,error) in
            let jsonPost = try! JSONSerialization.jsonObject(with: data!, options: []) as! [String: Any]
            print("creado en otro hilo")

            let postgetted = Post(idpar: jsonPost["id"] as! Int, userIdPar: jsonPost["userId"] as! Int, titltepar: jsonPost["title"] as! String, bodypar: jsonPost["body"] as! String)
            print(postgetted)
            
           
            
            DispatchQueue.main.async {
                self.llenarView(postgetted: postgetted)
            }
            
            
            
        }
        
        let tarea2 = session.dataTask(with: request2) { (data,response,error) in
                let jsonpost = try! JSONSerialization.jsonObject(with: data!, options: [])
                guard let jsonarray = jsonpost as? [[String: Any]] else {
                    return
                }
                for dic in jsonarray{
                    guard let title = dic["title"] as? String else { return }
                    print(title)
                }
            }
        tarea2.resume()
        tarea.resume()
        
        
    }
    
    
  func llenarView(postgetted: Post) {
                 self.idtxt.text = String(postgetted.id)
                 self.useridlab.text = String(postgetted.id)
                 self.titlelabe.text = postgetted.title as String
                 self.bodylabe.text = postgetted.body as String
                 
             }
    
}

