//
//  post.swift
//  Api
//
//  Created by DamII on 11/12/22.
//  Copyright © 2022 DamII. All rights reserved.
//

import Foundation
class Post {
    var id: Int
    var userId: Int
    var title: String
    var body: String
    
    init(idpar: Int, userIdPar: Int,titltepar: String, bodypar: String){
        self.id = idpar
        self.userId = userIdPar
        self.title = titltepar
        self.body = bodypar
    }
}
