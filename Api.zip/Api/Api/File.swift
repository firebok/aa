//
//  File.swift
//  Api
//
//  Created by DamII on 11/12/22.
//  Copyright © 2022 DamII. All rights reserved.
//

import Foundation

class <#name#>: <#super class#> {
    <#code#>
}
